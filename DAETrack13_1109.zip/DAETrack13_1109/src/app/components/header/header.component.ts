import { Component } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { SidebarComponent } from "../sidebar/sidebar.component";

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [TranslateModule, RouterModule, FormsModule, SidebarComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  searchQuery: string = '';
  isSidebarOpen: boolean = false;
  public isBlueIconLogin: boolean = false;  // Variabile per tenere traccia dello stato dell'icona
  public isModalOpen: boolean = false; 
  public user: { firstName: string, lastName: string, role: string } | null = null;

  constructor(private translate: TranslateService){}

  public changeLang(lang: string): void {
    this.translate.use(lang);
  }

  public onSearch(): void {
    console.log(this.searchQuery); 
  }

  public openSidebar(){
    this.isSidebarOpen = !this.isSidebarOpen;
  }
  
  onLogout() {
    this.user = null; // Resetta lo stato dell'utente
  }
  
  /*
  handleCloseModal() {
    this.isModalOpen = false;  
  }*/

  openModal() {
    if (!this.isModalOpen) {
      this.isModalOpen = true;
      this.isBlueIconLogin = true;  // Cambia icona in blu
    }
  }
  
  closeModal() {
    this.isModalOpen = false;   
    this.isBlueIconLogin = false;    // Cambia icona in nero
  }

  handleLoginSuccess(user: { firstName: string, lastName: string, role: string }) {
    this.user = user;
  }
}