import { Component } from '@angular/core';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatButtonModule} from '@angular/material/button';
import {MatBadgeModule} from '@angular/material/badge';
import {MatIconModule} from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';

@Component({
  selector: 'toolbar',
  standalone: true,
  imports: [MatButtonModule,MatBadgeModule,MatButtonToggleModule,MatIconModule,MatToolbarModule],
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.scss']
})
export class ToolbarComponent {

  notificationsCount: number = 3;
  alertsEnabled: boolean = true;

  // Metodi per gestire le azioni sui pulsanti
  toggleAlerts(): void {
    this.alertsEnabled = !this.alertsEnabled;
    console.log(`Le notifiche sono ora ${this.alertsEnabled ? 'abilitate' : 'disabilitate'}`);
  }

  applyFilter(): void {
    console.log('Filtro applicato!');
  }

  openSettings(): void {
    console.log('Impostazioni aperte!');
  }
}
