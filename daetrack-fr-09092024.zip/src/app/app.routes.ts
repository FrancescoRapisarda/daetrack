import { Routes } from '@angular/router';
import { ConfigurationComponent } from './components/configuration/configuration.component';
import { MapComponent } from './components/map/map.component';

export const routes: Routes = [
  { path: 'map', component: MapComponent},
  { path: 'configuration', component: ConfigurationComponent },
  { path: '', redirectTo: '/map', pathMatch: 'full' },
];
