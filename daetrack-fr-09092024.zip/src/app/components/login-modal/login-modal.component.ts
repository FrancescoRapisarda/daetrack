import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AuthService } from '../../services/authentication/auth.service';
import { FormsModule } from '@angular/forms';

// import * as Roles from 'src/app/common/constants/roles.ts';
// import * as StatusMessages from 'src/app/common/constants/status-messages.ts';

@Component({
  selector: 'app-login-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login-modal.component.html',
  styleUrl: './login-modal.component.css'
})
export class LoginModalComponent {
  
  isLoggedIn: boolean = false;  // l'utente è loggato?
  email: string = '';
  password: string = '';
  user: { firstName: string, lastName: string, phone: string, email: string } | null = null;
  warningMessage: boolean = false;
  warningMessageText: string = '';
  waitingResp: boolean = false;
  loadingSpinner: boolean = false;

  
  constructor() {}
  
  @Input() isOpenLogin = false;
  @Output() closeModal = new EventEmitter<void>();  // Evento per comunicare con il genitore
  @Output() loginSuccess = new EventEmitter<{ firstName: string, lastName: string, role: string }>(); // Evento per comunicare il login riuscito
  @Output() logout = new EventEmitter<void>();  // Evento per comunicare il logout
  
  
  // Aprire la modale di login
  openLoginModal() {
    this.isOpenLogin = true;
  }

  
  closeLoginModal() {
    //this.isOpenLogin = !this.isOpenLogin;
    this.isOpenLogin = false;
    this.closeModal.emit();  // Emette un evento per informare il genitore della chiusura
  }  
  
  

  onLogin() {
    // autenticazione (da sostituire con chiamata a un servizio di autenticazione)
    if (this.email === '1' && this.password === '1') {
      this.isLoggedIn = true;
      this.user = {
        firstName: 'Francesco',
        lastName: 'Rapisarda',
        phone: '(+39) 327 456 7890',
        email: 'rapisarda@example.com'
      };
      
      // Emetto l'evento di login riuscito
      this.loginSuccess.emit({
        firstName: this.user.firstName,
        lastName: this.user.lastName,
        role: 'Admin'
      });
      
      this.closeLoginModal(); // Chiudo la modale di login
      this.openLoginModal();  // Riapro la modale come profilo utente
    } else {
      alert('Credenziali non valide');
    }
  }
  

  
  onLogout() {
    this.isLoggedIn = false;
    this.user = null;
    this.logout.emit();  // Emetto un evento per informare il genitore del logout
    this.closeLoginModal(); // Chiudo modale del profilo utente
  }
  
  
  
  //onLogin con autenticazione (chiamata a un servizio di autenticazione)
  // onUserLogin() {
  //   this.waitingResp = true;
    
  //   if (this.warningMessage === true) {
  //     this.warningMessage = false
  //   }
    
  //   this.loadingSpinner = true;
    
  //   this.authService.login(this.email, this.password).subscribe(response => {
  //     this.loadingSpinner = false;
      
  //     if (response.message === "ok") {
  //       if (response.user.id === 1) {
  //         // The user is an administrator
  //         this.authorizeLogin(response.token, response.user);
  //       } else {
  //         // Check the user role
  //         switch (response.user.qualifica) {
  //           case Roles.Supervisore:
  //             this.authorizeLogin(response.token, response.user);
  //             break;
            
  //           case Roles.UtentePRO:
  //             if (response.user.abilitatore) {
  //               this.authorizeLogin(response.token, response.user);
  //             } else {
  //               this.warningMessageText = StatusMessages.DialogUserRoleNotAuthorizedError;
  //               this.warningMessage = true;
  //               this.password = "";
  //             }
  //             break;
            
  //           default:
  //             this.warningMessageText = StatusMessages.DialogUserRoleNotAuthorizedError;
  //             this.warningMessage = true;
  //             this.password = "";
  //             break;
  //         }
  //       }
  //     } else {
  //       this.warningMessageText = StatusMessages.DialogWrongUsernameError;
  //       this.warningMessage = true 
  //     }
  //   })
  // }
  
  // // Quando un login ha successo, questo metodo: 
  // // Salva il token: Usa authService per memorizzare il token di accesso.
  // // Salva il nome e le iniziali dell'utente.
  // // Navigazione: Reindirizza l'utente alla pagina (/...).
  // authorizeLogin(token: any, user: any) {
  //   throw new Error('Method not implemented.');
  // }
  
}
