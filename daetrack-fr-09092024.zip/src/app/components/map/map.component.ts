import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
// import L from 'leaflet'; 
import * as L from 'leaflet';
import { isPlatformBrowser } from '@angular/common';
import { PLATFORM_ID } from '@angular/core';  //Servizio PLATFORM_ID di Angular per verificare se il codice sta girando nel browser

@Component({
  selector: 'app-map',
  standalone: true,
  imports: [],
  templateUrl: './map.component.html',
  styleUrl: './map.component.css'
})
  
export class MapComponent implements OnInit {
  private map: any;
  // private cicle: any;
  private imageOverlay: any;
  private imageUrl: string = 'assets/elements/icons/DAEpin-red.png';
  private latLngBounds: L.LatLngBounds | null = null;
  private position: number[] = [37.552350, 15.145500];
  public locations: [number, number][] = [
    [37.552350, 15.145500],
    [37.552450, 15.145600],
    [37.552550, 15.145700]
  ];

  constructor(@Inject(PLATFORM_ID) private platformId: Object) { }
   
  
  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.loadLeaflet();
    }
  }
  
  private async loadLeaflet(): Promise<void> {
    const L = await import('leaflet');
    this.latLngBounds = L.latLngBounds([[this.position[0] + 0.00007812313348409816, this.position[1] + 0.00007812313348409816], [37.55224859017356, 15.14535604356571]]);
    this.initMap(L);
  }

  
    private initMap(L: any): void {
      this.map = L.map('map').setView(this.position, 18); // Coordinate local
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: ''
    }).addTo(this.map);
    
  // this.cicle = L.circle(this.position, {
	// color: 'red',
	// fillColor: '#f03',
	// fillOpacity: 0.5,
	// radius: 5
  // }).addTo(this.map);
      
  this.imageOverlay = L.imageOverlay(this.imageUrl, this.latLngBounds, {
    opacity: 1.0,
	  // errorOverlayUrl: errorOverlayUrl,
	  // alt: altText,
	  interactive: true 
    }).addTo(this.map);   
  }
}

