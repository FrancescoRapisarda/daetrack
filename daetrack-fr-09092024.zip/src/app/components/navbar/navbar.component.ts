import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { SidebarComponent } from "../sidebar/sidebar.component";
import { LoginModalComponent } from "../login-modal/login-modal.component";
import { EventEmitter } from 'stream';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, SidebarComponent, LoginModalComponent],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
  
export class NavbarComponent {
  public isSidebarOpen: boolean = false;
  public isBlueIconLogin: boolean = false;  // Variabile per tenere traccia dello stato dell'icona
  public isModalOpen: boolean = false; // Variabile per la modale
  public user: { firstName: string, lastName: string, role: string } | null = null;
  
  
    // logout dell'utente
   onLogout() {
    console.log('Utente disconnesso');
    this.user = null; // Resetta lo stato dell'utente
  }
  
  toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
  }
  
   handleCloseModal() {
    this.isModalOpen = false;  // Chiude modale
  }

  openModal() {
    if (!this.isModalOpen) {
      this.isModalOpen = true;
      this.isBlueIconLogin = true;  // Cambia icona in blu
    }
  }
  
   closeModal() {
    this.isModalOpen = false;   // Imposta modale come chiusa
    this.isBlueIconLogin = false;    // Cambia icona in nero
  }
  

  // Metodo per gestire l'evento di login riuscito
  handleLoginSuccess(user: { firstName: string, lastName: string, role: string }) {
    this.user = user;
  }
}
