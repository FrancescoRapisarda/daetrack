import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { AuthService } from '../../services/authentication/auth.service';
import { AccordionComponent } from "../accordion/accordion.component";

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, AccordionComponent],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css'
})
export class SidebarComponent {
  @Input() isOpen = false;
  @Input() isLoggedIn: boolean = false;  // Stato di login passato dal componente genitore

   toggleSidebar() {
    this.isOpen = !this.isOpen;
  }

}
