import { Component, Inject, EventEmitter, Output } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { PublicMessageDetails } from '../../interfaces/notifications/notification';
import { NotificationService } from '../../services/notification.service';
import { AuthService } from '../../services/authentication/auth.service';

@Component({
  selector: 'app-segnalation-card',
  standalone: true,
  imports: [TranslateModule, CommonModule],
  templateUrl: './segnalation-card.component.html',
  styleUrls: ['./segnalation-card.component.scss']
})

export class SegnalationCardComponent {
  private username: string | null;
  isCardVisible: boolean = true;
  messageDetails: PublicMessageDetails;
  
  @Output() statusUpdated: EventEmitter<void> = new EventEmitter<void>();
  
  constructor(
        @Inject(MAT_DIALOG_DATA) public data: PublicMessageDetails,
        private dialogRef: MatDialogRef<SegnalationCardComponent>,
        private notificationService: NotificationService,
        private authService: AuthService
    ) {
        this.messageDetails = data || { Pictures: [] }; 
        this.username = this.authService.getUsername();
    }

  downloadAttachment(attachmentID: string) {

    if(this.username){
      this.notificationService.getPublicMessageAttachment(this.username, attachmentID).subscribe((response: any) => {
        const { Filename, Stream } = response;
        
        if (Stream) {
          const link = document.createElement('a');

          /* NOTE: application/octet-stream indica un file binario generico. È utilizzato per qualsiasi tipo di file che non ha un formato specifico (come PDF, immagini, ecc.).
                   Indica al browser che il contenuto è un file scaricabile, non qualcosa da visualizzare direttamente sulla pagina. */
          link.href = `data:application/octet-stream;base64,${Stream}`;
          link.download = Filename; 
          document.body.appendChild(link);
          link.click(); 
          document.body.removeChild(link); // Rimuove il link dopo il click
        }
    });
    }
  }

  updateStatusMessage(NewStatus: string) {
  const publicMessageID = this.messageDetails.PublicMessageID;


  if(this.username){
    this.notificationService.updateNotificationStatus(this.username, publicMessageID, NewStatus).subscribe(
      (response) => {
        alert('Stato aggiornato con successo');
        this.statusUpdated.emit();
        this.dialogRef.close();
      },
      (error) => {
        console.error('Errore durante l\'aggiornamento dello stato:', error);
      }
    );
  }
}

  closeCard() {
    this.isCardVisible = false;
    this.dialogRef.close();
  }
}