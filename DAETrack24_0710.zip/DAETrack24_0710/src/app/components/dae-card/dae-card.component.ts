import { Component, Input, OnDestroy } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import { DAEparams } from '../../interfaces/dae/DAEparams';
import { AuthService } from '../../services/authentication/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-dae-card',
  standalone: true,
  imports: [TranslateModule, CommonModule],
  templateUrl: './dae-card.component.html',
  styleUrl: './dae-card.component.scss'
})
export class DaeCardComponent implements OnDestroy{
  @Input() data!: DAEparams; 
  @Input() notifications: any[] = [];
  @Input() selectedMarker!: HTMLElement;

  isLogged: boolean = false;
  isNotificationsEnabled: boolean = this.isLogged;
  private authSubscription!: Subscription;

  constructor(private authService: AuthService){
    this.authSubscription = this.authService.isLoggedIn.subscribe(isLoggedIn => {
      (isLoggedIn) ? this.isLogged = true : this.isLogged = false;
    })
  }
  
  ngOnDestroy(): void {
    this.authSubscription.unsubscribe();
  }

  public closeCard(){
    const DAEcard = document.querySelector('.dae-card') as HTMLElement;
    DAEcard.classList.add('dae-card-hidden');

    // The marker returns to it's original style
    this.selectedMarker.style.width = "45px";
    this.selectedMarker.style.height = "35px";
    this.selectedMarker.style.border = "none";
    this.selectedMarker.style.borderRadius = "0";
  }
}