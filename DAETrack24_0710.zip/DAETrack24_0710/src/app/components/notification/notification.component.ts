import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { NotificationService } from '../../services/notification.service';
import { CommonModule } from '@angular/common';
import { MatExpansionModule } from '@angular/material/expansion';
import { SegnalationCardComponent } from '../segnalation-card/segnalation-card.component';
import { MatDialog } from '@angular/material/dialog';
import { DAEPublicMessagesResponse, DAEPublicMessageGroup, PublicMessageDetails } from '../../interfaces/notifications/notification';
import { TranslateModule } from '@ngx-translate/core';
import { AuthService } from '../../services/authentication/auth.service';

@Component({
  selector: 'app-notification',
  standalone: true,
  imports: [CommonModule, MatExpansionModule, TranslateModule],
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent implements OnInit {
  DAEPublicMessagesList: DAEPublicMessageGroup[] = [];
  private username: string | null;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<NotificationComponent>,
    private notificationService: NotificationService,
    private authService: AuthService,
    private dialog: MatDialog
  ) {
    this.username = this.authService.getUsername();
  }

  ngOnInit(): void {
    this.loadNotifications();
  }

  public loadNotifications(): void {
    const status = 'OPEN';

    if(this.username){
      this.notificationService.getNotifications(this.username, status).subscribe((response: DAEPublicMessagesResponse) => {
        this.DAEPublicMessagesList = response.DAEPublicMessages;
      });
    }
  }

  public onMessageClick(message: any): void {
    const id = message.ID_PublicMessage;

    if(this.username){
      this.notificationService.getPublicMessageDetails(this.username, id).subscribe((response: PublicMessageDetails) => {
        this.openSegnalationCard(response);
        this.notificationService.setMessageDetailsSource(response);
        this.close();
      });
    }
  }

  public openSegnalationCard(messageDetails: PublicMessageDetails): void {
    const dialogRef = this.dialog.open(SegnalationCardComponent, {
      data: messageDetails,
    });

    dialogRef.componentInstance.statusUpdated.subscribe(() => {
      this.loadNotifications();
    });
  }

  public close(): void {
    this.dialogRef.close();
  }
}