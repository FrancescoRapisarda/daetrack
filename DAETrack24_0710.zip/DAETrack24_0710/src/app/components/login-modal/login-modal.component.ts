import { CommonModule } from '@angular/common';
import { Component, EventEmitter, inject, Input, OnDestroy, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClient, HttpClientModule} from '@angular/common/http';
import { AuthService } from '../../services/authentication/auth.service';

import * as StatusMessages from '../../common/constants/status-messages';
import { Subscription } from 'rxjs';
import { User } from '../../interfaces/user/user';

@Component({
  selector: 'app-login-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule,TranslateModule, HttpClientModule],
  templateUrl: './login-modal.component.html',
  styleUrl: './login-modal.component.scss',
})
  
export class LoginModalComponent implements OnDestroy{
  loginObj: any = {
    "UsernameOrEmail": '',
    "Password": ''
  }
  isLoggedIn: boolean = false;
  user!: User;
  warningMessage: boolean = false;
  warningMessageText: string = '';
  waitingResp: boolean = false;
  loadingSpinner: boolean = false;
  private authSubscription: Subscription;

  @Input() isOpenLogin = false;
  @Output() userData = new EventEmitter<any>();
  @Output() logout = new EventEmitter<boolean>();
  @Output() closeModal = new EventEmitter<void>();
  
  http = inject(HttpClient);

  constructor(private authService: AuthService) {
    this.authSubscription = this.authService.isLoggedIn.subscribe(isLoggedIn => {
      (isLoggedIn) ? this.isLoggedIn = true : this.isLoggedIn = false;
    })
  }

  ngOnDestroy(): void {
    this.authSubscription.unsubscribe();
  }
  
  public openLoginModal() {
    this.isOpenLogin = true;
  }

  public closeLoginModal() {
    this.isOpenLogin = false;
    this.closeModal.emit();
  }  
   
  public onLogout() {
    this.authService.logout();
    this.logout.emit(true);
    this.isLoggedIn = false;
    this.closeLoginModal(); 
  }

  public onUserLogin() {
    this.waitingResp = true;  
    
    if (this.warningMessage === true) {
      this.warningMessage = false
    }
    
    this.loadingSpinner = true;
    
    this.authService.login(this.loginObj.UsernameOrEmail, this.loginObj.Password).subscribe({
      next: response => {
        if(response){
          this.user = response;
          this.user.Phone = "+49 327 8761 474";

          // To show the user's details in the header
          this.userData.emit(this.user);

          this.isLoggedIn = true;
          this.closeLoginModal(); 
        }
        else {
          alert("Check User Mail or Password");
        }
      }, 
      error: (error) => {
        //Unauthorized
        if (error.status === 401) {
          this.warningMessageText = StatusMessages.DialogWrongUsernameError;
          this.warningMessage = true;
          this.loginObj.password = "";
        } else {
          this.warningMessageText = StatusMessages.DialogServerNotReachableError;
          this.warningMessage = true;
        }
        this.waitingResp = false;
      }
    });
  } 
}