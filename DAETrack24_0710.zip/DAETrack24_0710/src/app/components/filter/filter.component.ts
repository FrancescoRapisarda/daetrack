import { AfterContentChecked, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { activeStatus, allStatus, inactiveStatus } from '../../common/constants/constants';
import { TranslateModule } from '@ngx-translate/core';
import { DaeStatusService } from '../../services/dae-status.service';
import { Subscription } from 'rxjs';
import { DomEvent } from 'leaflet';

@Component({
  selector: 'app-filter',
  standalone: true,
  imports: [TranslateModule],
  templateUrl: './filter.component.html',
  styleUrl: './filter.component.scss'
})
export class FilterComponent implements OnInit{
  @Input() isFilterOpen!: boolean;
  @Output() filterStatusChange = new EventEmitter<string>();
  @Output() isFilterOpenChange = new EventEmitter<boolean>();

  status: string = activeStatus;

  private daeStatusSubscription: Subscription;

  constructor(private daeStatusService: DaeStatusService){
    this.daeStatusSubscription = this.daeStatusService.currentStatus.subscribe((status) => {
      this.status = status;
    });
  }

  ngOnInit(): void {
    const filter = document.querySelector('.dropdown') as HTMLElement;
    if(filter){
      DomEvent.disableClickPropagation(filter); 
    }
  }
  
  public showActiveDAE(){
    this.status = activeStatus;
    this.daeStatusService.setStatus(activeStatus);

    // to avoid displaying the filter
    this.isFilterOpenChange.emit(!this.isFilterOpen);
  }

  public showInctiveDAE(){
    this.status = inactiveStatus;
    this.daeStatusService.setStatus(inactiveStatus);

    this.isFilterOpenChange.emit(!this.isFilterOpen);
  }

  public showAllDAE(){
    this.status = allStatus;
    this.daeStatusService.setStatus(allStatus);

    this.isFilterOpenChange.emit(!this.isFilterOpen);
  }
}
