import { Component, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { SidebarComponent } from "../sidebar/sidebar.component";
import { LoginModalComponent } from "../login-modal/login-modal.component";
import { LocationService } from '../../services/location.service';
import { User } from '../../interfaces/user/user';
import { AddressData } from '../../interfaces/address/AddressData';
import { ChangeLocationService } from '../../services/change-location.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, TranslateModule,RouterModule,FormsModule,SidebarComponent, LoginModalComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent implements OnDestroy{
public isSidebarOpen: boolean = false;
  public isBlueIconLogin: boolean = false;  
  public isModalOpen: boolean = false; 
  user: User | null = null;

  isSubmitted: boolean = false;
  searchedAddress: string = '';
  addressesArray: Array<any> = [];

  private isChangeLocationEnabled: boolean = false;

  //private changeLocationSubscription: Subscription;

  constructor(
    private translate: TranslateService, 
    private locationService: LocationService,
    private changeLocationService: ChangeLocationService
  ){
    /*
    this.changeLocationSubscription = this.changeLocationService.currentCursor.subscribe((isChangeLocationEnabled) => {
      this.isChangeLocationEnabled = isChangeLocationEnabled;
    })*/
  }

  ngOnDestroy(): void {
    //this.changeLocationSubscription.unsubscribe();
  }

  public changeLang(lang: string): void {
    this.translate.use(lang);
  }

  public onSubmit(): void{
    const searchBarInput = document.querySelector('.search-bar-input input') as HTMLElement;
    searchBarInput.style.borderBottomLeftRadius = '0';
    searchBarInput.style.borderBottomRightRadius = '0';

    const searchForm = document.querySelector('#searchForm input') as HTMLInputElement;
    this.searchedAddress = searchForm.value;

    this.locationService.getAddress(this.searchedAddress).subscribe((response: any) => {
      this.addressesArray = response;

      this.isSubmitted = !this.isSubmitted;
    });
  }

  public onAddressClick(selectedAddress: AddressData): void{
    this.locationService.updateAdress(selectedAddress);
    this.isSubmitted = !this.isSubmitted;

    const searchBarInput = document.querySelector('.search-bar-input input') as HTMLElement;
    searchBarInput.style.borderBottomLeftRadius = '30px';
    searchBarInput.style.borderBottomRightRadius = '30px';

    const resultsContainer = document.getElementById('results-container') as HTMLElement;
    resultsContainer.style.display = 'none';
  }

  public updateUser(user: User){
    this.user = user;
  }
  
  public onLogout() {
    this.user = null; 
  }
  
  public toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
  }

  public openModal() {
    if (!this.isModalOpen) {
      this.isModalOpen = true;
      this.isBlueIconLogin = true;  // Cambia icona in blu
    }
  }
  
  public closeModal() {
    this.isModalOpen = false;   // Imposta modale come chiusa
    this.isBlueIconLogin = false;    // Cambia icona in nero
  }

  public changeLocation(): void{
    const changeLocationButton = document.querySelector('.change-location-button');

    this.isChangeLocationEnabled = !this.isChangeLocationEnabled;
    this.changeLocationService.setChangeLocation(this.isChangeLocationEnabled);

    if(changeLocationButton){
      if(this.isChangeLocationEnabled){
        changeLocationButton.classList.add('change-location-button-selected');
      }
      else{
        changeLocationButton.classList.remove('change-location-button-selected');
      }
    }
  }
}