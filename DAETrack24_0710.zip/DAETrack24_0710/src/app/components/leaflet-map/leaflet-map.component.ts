import { defaultDistance, defaultLatitude, defaultLongitude, activeStatus, allStatus } from '../../common/constants/constants';
import { Map, latLng, tileLayer, LayerGroup, MapOptions, Marker, Circle, Icon, DomEvent, LeafletMouseEvent } from "leaflet";
import { Component, Input, OnInit } from '@angular/core';
import { environment } from '../../../environments/environment'; 
import { DaeCardComponent } from '../dae-card/dae-card.component';
import { SliderComponent } from "../slider/slider.component";
import { ToolbarComponent } from '../toolbar/toolbar.component';
import { FilterComponent } from '../filter/filter.component';
import { DaeService } from '../../services/dae.service';
import { DAEparams } from '../../interfaces/dae/DAEparams';
import { DAEdata } from '../../interfaces/dae/DAEdata';
import { LocationService } from '../../services/location.service';
import { NotificationService } from '../../services/notification.service';
import { AuthService } from '../../services/authentication/auth.service';
import { Subscription } from 'rxjs';
import { PublicMessageDetails } from '../../interfaces/notifications/notification';
import { AddressData } from '../../interfaces/address/AddressData';
import { ChangeLocationService } from '../../services/change-location.service';
import { DaeStatusService } from '../../services/dae-status.service';

@Component({
  selector: 'app-leaflet-map',
  standalone: true,
  imports: [DaeCardComponent, SliderComponent, ToolbarComponent, FilterComponent],
  templateUrl: './leaflet-map.component.html',
  styleUrl: './leaflet-map.component.scss'
})
export class LeafletMapComponent implements OnInit{
  map!: Map;
  markersLayer!: LayerGroup;
  addressMarkersLayer: LayerGroup = new LayerGroup();

  selectedDae: DAEparams | undefined; 
  selectedDaeNotifications: any[] = [];
  selectedMarker!: HTMLElement; 
  previousMarker: HTMLElement | undefined; 
  circle!: Circle | null;

  DAEList: DAEparams[] = [];
  notificationList!: any;
  searchedAddressData: AddressData | null = null;
  notificationData: any;
  clickCount: number = 0;

  username: string | null;
  private distance: string = defaultDistance;
  private userLatitude: string = defaultLatitude;
  private userLongitude: string = defaultLongitude;
  private clickedLocationLat: string | null = null;
  private clickedLocationLng: string | null = null

  isLogged: boolean = false;
  private authSubscription!: Subscription;
  private locationSubscription!: Subscription;
  private notificationSubscription!: Subscription;
  private changeLocationSubscription!: Subscription;
  private daeStatusSubscription!: Subscription;

  private notificationDetails: PublicMessageDetails | null = null;
  private isChangeLocationEnabled: boolean = false;

  private intervalID: any;
  status: string = activeStatus;
  
constructor(
    private daeService: DaeService, 
    private locationService: LocationService, 
    private notificationService: NotificationService,
    private authService: AuthService,
    private changeLocationService: ChangeLocationService,
    private daeStatusService: DaeStatusService
  ){
    this.notificationSubscription = this.notificationService.currentMessageDetailsSource.subscribe(message => {
      this.notificationDetails = message;

      if(this.notificationDetails !== null){
        if(this.searchedAddressData){
          this.onMarkerAddressClick();
        }

        if(this.clickedLocationLat && this.clickedLocationLng){
          this.clickedLocationLat = null;
          this.clickedLocationLng = null;
        }

        this.daeStatusService.setStatus(allStatus);

        this.updateMap(Number(this.distance));
      }
    })

    this.changeLocationSubscription = this.changeLocationService.currentCursor.subscribe((isChangeLocationEnabled) => {
      this.isChangeLocationEnabled = isChangeLocationEnabled;

      if(this.isChangeLocationEnabled === true){
        this.map.getContainer().style.cursor = 'crosshair';
        //this.map.getContainer().classList.add('change-location-cursor');
        
        this.map.on('click', (e) => {
          this.clickedLocationLat = String(e.latlng.lat);
          this.clickedLocationLng = String(e.latlng.lng);

          if(this.searchedAddressData){
            this.onMarkerAddressClick();
          }
          else {
            this.updateMap(Number(this.distance));
          }        
        })
      }
      else{
        if(this.map){
          this.map.getContainer().style.cursor = '';

          this.map.off('click');
          this.clickedLocationLat = null;
          this.clickedLocationLng = null;
          if(document.getElementById('map'))

          this.updateMap(Number(this.distance));
        }
      }
    })

    this.daeStatusSubscription = this.daeStatusService.currentStatus.subscribe((status) => {
      this.status = status;

      if(this.map){
        this.updateMap(Number(this.distance));
      }
    });

    this.username = this.authService.getUsername();
  }

  options: MapOptions = {
    center: latLng(Number(defaultLatitude), Number(defaultLongitude)),
    zoom: 14
  };

  ngOnInit(): void {
    this.initMap();
    
    // Checking if the token is setted
    this.authSubscription = this.authService.isLoggedIn.subscribe(isLoggedIn => {
      (isLoggedIn) ? this.isLogged = true : this.isLogged = false;

      if(this.isLogged === false) {
        this.status = activeStatus;
        this.updateMap(Number(this.distance));
      } 
      else {
        this.intervalID = setInterval(() => {
          this.loadNotifications();
        }, 600000);
      }
    })

    // Subscribing to the Observable to obtain the selected address after searching
    this.locationSubscription = this.locationService.currentAddress.subscribe(data => {
      if(data){
        this.searchedAddressData = data;
        this.changeLocationToSelectedAddress();
      }
    })
  }
  
  ngOnDestroy(): void {
    this.authSubscription.unsubscribe();
    this.locationSubscription.unsubscribe();
    this.notificationSubscription.unsubscribe();
    this.changeLocationSubscription.unsubscribe();
    this.daeStatusSubscription.unsubscribe();
  }

  // Removes the marker and centers the map's view to the user's location
  private onMarkerAddressClick = () => {
    if(this.map.hasLayer(this.addressMarkersLayer))
      this.addressMarkersLayer.clearLayers();

    this.searchedAddressData = null;
    this.updateMap(Number(this.distance));
  }

  private changeLocationToSelectedAddress(){
    if(this.map.hasLayer(this.addressMarkersLayer))
      this.addressMarkersLayer.clearLayers();

    if(this.map.hasLayer(this.markersLayer)){
      this.markersLayer.clearLayers();
    }

    if(this.clickedLocationLat && this.clickedLocationLng){
      this.clickedLocationLat = null;
      this.clickedLocationLng = null;
    }

    if(this.notificationDetails){
      this.notificationDetails = null;
    }

    if(this.searchedAddressData){
      let selectedAddressMarker = new Marker([Number(this.searchedAddressData.lat), Number(this.searchedAddressData.lon)]).addTo(this.map!);
      selectedAddressMarker.addEventListener("click", this.onMarkerAddressClick);

      // Add the marker to markersLayer
      selectedAddressMarker.addTo(this.addressMarkersLayer);
      this.map.addLayer(this.addressMarkersLayer);
      selectedAddressMarker.addTo(this.map);
          
      this.updateMap(Number(this.distance));
    }
  }

  public onUpdateStatus(status: string): void {
    this.status = status;
    this.updateMap(Number(this.distance));
  }

  private loadNotifications(): void {
    const status = 'OPEN';

    if(this.username){
      this.notificationService.getNotifications(this.username, status).subscribe({
        next: (response) => {
          console.log('Notifiche caricate', response);
        },
        error: (error) => {
          console.error('Errore nel caricamento delle notifiche', error);
        }
      });
    }
  }
  /*
  private getNotificationsDetails(messageID: string): void{
    this.notificationService.getPublicMessageDetails(this.username, messageID).subscribe((response: any) => {
      this.selectedDaeNotifications.push(response);
    });
  }*/

  private onMarkerClick(selectedDaeId: string, event: LeafletMouseEvent): void {
    const DAEcard = document.querySelector('.dae-card') as HTMLElement;
    //let notifications = [];

    if(DAEcard){
      DAEcard.classList.remove('dae-card-hidden');
    }

    this.clickCount++;

    this.selectedDae = this.DAEList.find(d => d.ID === selectedDaeId);

    /*if(this.isLogged){
      console.log('islogged marker');
      this.selectedDaeNotifications = this.notificationList.find((n: any) => n.ID_DAE === selectedDaeId);
    }*/
   
    /*
    if(notifications = this.notificationList.find((n: any) => n.ID_DAE === selectedDaeId)){
      notifications.PublicMessages.forEach((message: any) => {
        this.getNotificationsDetails(message.ID_PublicMessage);
      });
    }*/

    if(this.previousMarker && this.clickCount > 1){
      // Remove previousDae style
      this.previousMarker.style.width = "45px";
      this.previousMarker.style.height = "35px";
      this.previousMarker.style.border = "none";
      this.previousMarker.style.borderRadius = "0";
    }

    this.selectedMarker = event.target.getElement();
    this.previousMarker = this.selectedMarker;
    
    if(this.selectedMarker){
      this.selectedMarker.style.width = "60px";
      this.selectedMarker.style.height = "auto";
      this.selectedMarker.style.border = "4px solid #0A9BD8";
      this.selectedMarker.style.borderRadius = "12px";
    }
  }

  private changeZoomStyle(): void {
    const zoomControl = this.map.zoomControl;
    zoomControl.setPosition('bottomright');
    
    const zoomInButton = document.querySelector('.leaflet-control-zoom-in') as HTMLElement;
    const zoomOutButton = document.querySelector('.leaflet-control-zoom-out') as HTMLElement;
    zoomInButton.style.color = '#0A9BD8';
    zoomOutButton.style.color = '#0A9BD8';
  }

  private updateMap(distance: number): void{
    // Remove previous markers
    if(this.map.hasLayer(this.markersLayer)){
      this.markersLayer.clearLayers();
    }

    this.getDAE();

    if(this.clickedLocationLat && this.clickedLocationLng){
      this.drawCircle(Number(this.clickedLocationLat), Number(this.clickedLocationLng), Number(distance));
    }
    else if(this.searchedAddressData){
      this.drawCircle(Number(this.searchedAddressData.lat), Number(this.searchedAddressData.lon), Number(distance));
    }
    else if(this.notificationDetails){
      this.drawCircle(Number(this.notificationDetails.DAELatitude), Number(this.notificationDetails.DAELongitude), Number(distance));
    }
    else {
      this.drawCircle(Number(this.userLatitude), Number(this.userLongitude), Number(distance));
    }
  }

  public onDistanceChange(event: MouseEvent): void{
    let target = event.target as HTMLInputElement;
    
    this.distance = target.value;
    this.updateMap(Number(this.distance));
  }

  private drawCircle(lat: number, lng: number, distance: number){
    // Remove the previous circle
    if(this.circle)
      this.map.removeLayer(this.circle);
      
    this.circle = new Circle([lat, lng], {radius: distance}).addTo(this.map);
    this.circle.setStyle({color: "#0A9BD8"});
  }

  private getDAE(): void{
    let daeData: DAEdata = {
      latitude: (this.clickedLocationLat) ? this.clickedLocationLat : ((this.notificationDetails) ? this.notificationDetails.DAELatitude : (this.searchedAddressData) ? this.searchedAddressData.lat : this.userLatitude),
      longitude: (this.clickedLocationLng) ? this.clickedLocationLng : ((this.notificationDetails) ? this.notificationDetails.DAELongitude : (this.searchedAddressData) ? this.searchedAddressData.lon : this.userLongitude),
      distance: this.distance,
      status: this.status
    }

    // API request
    this.daeService.getDAEByDistance(daeData).subscribe((response: any) => {
      this.DAEList = response.DAEList;

      this.DAEList.forEach(element => {
        let elementIconUrl: string = '';
        
        switch(element.Status){
          case 'ACTIVE':
            elementIconUrl = 'assets/icons/DAEpin-green.png';
            break;

          case 'INACTIVE':
            elementIconUrl = 'assets/icons/DAEpin-red.png';
            break;
        }
  
        // Icon
        let leafIcon = new Icon({
          iconUrl: elementIconUrl,
          iconSize: [45, 35]
        });
  
        let marker = new Marker([Number(element.Latitude), Number(element.Longitude)], {icon: leafIcon}).addTo(this.map!);
        marker.addEventListener("click", (event) => this.onMarkerClick(element.ID, event));

        // Add the marker to markersLayer
        marker.addTo(this.markersLayer);
      });

      // Add markersLayer to the map
      this.map.addLayer(this.markersLayer);
    });
  }
  
  private initMap(): void {
    const key = environment.apiKey;

    this.map = new Map('map', this.options);
    this.map.locate({setView: true, maxZoom: 14});

    this.markersLayer = new LayerGroup();

    // To prevent the map being dragged when dragging/clicking the slider
    const slider = document.getElementById('slider');
    if (slider) {
      DomEvent.disableClickPropagation(slider); 
      DomEvent.disableScrollPropagation(slider); 
    }
    
    // When the user location is found
    this.map.on('locationfound', (locationEvent) => {
      this.userLatitude = locationEvent.latlng.lat.toString();
      this.userLongitude = locationEvent.latlng.lng.toString();

      this.drawCircle(Number(this.userLatitude), Number(this.userLongitude), Number(defaultDistance));
      this.getDAE();
    });
    
    this.changeZoomStyle();

    tileLayer(`https://api.maptiler.com/maps/streets-v2/{z}/{x}/{y}.png?key=${key}`, {
      tileSize: 512,
      zoomOffset: -1,
      minZoom: 1,
      attribution: "\u003ca href=\"https://www.maptiler.com/copyright/\" target=\"_blank\"\u003e\u0026copy; MapTiler\u003c/a\u003e \u003ca href=\"https://www.openstreetmap.org/copyright\" target=\"_blank\"\u003e\u0026copy; OpenStreetMap contributors\u003c/a\u003e",
      crossOrigin: true
    }).addTo(this.map!);
  }
}