export interface Address{
    ISO3166_2_lvl4: string,
    ISO3166_2_lvl6: string,
    country: string, 
    country_code: string,
    county: string,
    neighbourhood: string,
    postcode: string,
    road: string,
    state: string,
    town: string
}