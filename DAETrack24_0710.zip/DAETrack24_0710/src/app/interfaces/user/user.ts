export interface User{
    Email: string,
    FiscalCode: string,
    Lastname: string,
    Name: string,
    Phone?: string,
    Role: string,
    Username: string
}