export interface DAEdata{
    latitude: string,
    longitude: string,
    distance: string,
    status: string
}