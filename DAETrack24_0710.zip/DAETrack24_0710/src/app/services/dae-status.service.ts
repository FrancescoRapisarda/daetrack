import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { activeStatus } from '../common/constants/constants';

@Injectable({
  providedIn: 'root'
})
export class DaeStatusService {
  private daeStatusSource: BehaviorSubject<string>;
  currentStatus: Observable<string>;

  constructor() {
    this.daeStatusSource = new BehaviorSubject(activeStatus);
    this.currentStatus = this.daeStatusSource.asObservable();
  }

  public setStatus(status: string){
    this.daeStatusSource.next(status);
  }
}
