import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JwtHelperService } from "@auth0/angular-jwt";
import { BehaviorSubject, map, Observable } from 'rxjs';
import { User } from '../../interfaces/user/user';
import * as ServiceUrls from "../../common/constants/service-urls";

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private jwtHelper: JwtHelperService;
  private isLoggedInSource: BehaviorSubject<boolean>;
  private user: any;
  isLoggedIn: Observable<boolean>;

  constructor(private http: HttpClient) {
    this.jwtHelper = new JwtHelperService();
    this.isLoggedInSource = new BehaviorSubject(false);
    this.isLoggedIn = this.isLoggedInSource.asObservable();
  }

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'RequestSource': 'Web' 
    })
  };

  public setIsLoggedIn(isLoggedIn: boolean) {
    return this.isLoggedInSource.next(isLoggedIn);
  }

  public setUsername(username: string): void{
    sessionStorage.setItem('username', username);
  }
  
  public getUsername(): string | null {
    let username: string;
    let token = this.getToken();
    
    if (token) {
      let decodedToken = this.jwtHelper.decodeToken(token);
      username = decodedToken.unique_name;
    }
    
    return sessionStorage.getItem("username");
  }
  
  public getToken(): string | null {
    return sessionStorage.getItem('dae_data');
  }
  
  public setToken(token: string | null): void {
    if(token) {
      sessionStorage.setItem('dae_data', token);
      this.setIsLoggedIn(true); 
    }
  }
  
  public removeToken(): void {
    sessionStorage.removeItem('dae_data');
    this.setIsLoggedIn(false);  
  }

  public login(usernameOrEmail: string, password: string): Observable<User | null> {
    const loginData = {
      UsernameOrEmail: usernameOrEmail,
      Password: password
    };
    
    return this.http.post<User>(ServiceUrls.Login, loginData, { ...this.httpOptions, observe: 'response' }).pipe(
      map(response => {
        // Get the token from the "Authorization" header
        let token = response.headers.get("Authorization");
        this.user = response.body;
        
        if(token) {
          // Store the token into session storage
          this.setToken(token);
          this.setUsername(this.user.Username);
        }
        else {
          throw new Error("Token is null");
        }
        
        return response.body;
      })
    );
  }

  public logout(): void{
    this.removeToken();
  }
}