import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChangeLocationService {
  private changeLocationSource: BehaviorSubject<boolean>;
  currentCursor: Observable<boolean>;

  constructor() { 
    this.changeLocationSource = new BehaviorSubject(false);
    this.currentCursor = this.changeLocationSource.asObservable();
  }

  public setChangeLocation(changeLocationValue: boolean): void {
    this.changeLocationSource.next(changeLocationValue);
  }
}
