import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as ServiceUrls from '../common/constants/service-urls';
import { AddressData } from '../interfaces/address/AddressData';

@Injectable({
  providedIn: 'root'
})
export class LocationService {
  private addressSource = new BehaviorSubject<AddressData | null>(null);
  currentAddress = this.addressSource.asObservable();

  httpOption = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  constructor(private http: HttpClient) {}

  public getAddress(address: string): Observable<AddressData>{
    return this.http.get<AddressData>(ServiceUrls.SearchAddress + 'q=' + address + '&format=json&addressdetails=1', this.httpOption);
  }

  public updateAdress(addressData: AddressData){
    this.addressSource.next(addressData);
  }
}