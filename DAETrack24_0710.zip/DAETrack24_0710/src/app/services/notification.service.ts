import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { DAEPublicMessagesResponse, PublicMessageDetails } from '../interfaces/notifications/notification';
import * as ServiceUrls from '../common/constants/service-urls';
import { AuthService } from './authentication/auth.service';

@Injectable({
  providedIn: 'root',
})
export class NotificationService {
  private token: string | null = null;
  private apiUrl = 'http://10.172.37.19:5055/api/Notifications/GetAllPublicMessages';

  private notificationsCount: BehaviorSubject<number>;
  private messageDetailsSource: BehaviorSubject<any>;
  private notificationSource: BehaviorSubject<any>;
  notificationsCount$: Observable<number>;
  currentMessageDetailsSource: Observable<any>;
  currentNotification: Observable<any>;

  constructor(private http: HttpClient, private authService: AuthService) {
    this.authService.isLoggedIn.subscribe(isLoggedIn => {
      (isLoggedIn) ? this.token = this.authService.getToken() : null;
    })

    this.notificationsCount = new BehaviorSubject(0);
    this.notificationsCount$ = this.notificationsCount.asObservable();

    this.messageDetailsSource = new BehaviorSubject(null);
    this.currentMessageDetailsSource = this.messageDetailsSource.asObservable();

    this.notificationSource = new BehaviorSubject(null);
    this.currentNotification = this.notificationSource.asObservable();
  }

  public setMessageDetailsSource(message: any){
    return this.messageDetailsSource.next(message);
  }

  public getNotifications(username: string, status: string): Observable<DAEPublicMessagesResponse> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.token}`,
      'Content-Type': 'application/json'
    });

    const body = {
      Username: username,
      Status: status
    };

    return this.http.post<DAEPublicMessagesResponse>(this.apiUrl, body, { headers }).pipe(
      tap((response: DAEPublicMessagesResponse) => {
        const totalMessages = response.DAEPublicMessages.reduce((acc, group) => acc + group.PublicMessages.length, 0);
        this.notificationsCount.next(totalMessages);
    })
    );
  }

  public getPublicMessageDetails(username: string, ID_PublicMessage: string): Observable<any> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.token}`,
      'Content-Type': 'application/json'
    });
    const body = {
      Username: username,
      PublicMessageID: ID_PublicMessage
    };

    return this.http.post<any>(ServiceUrls.GetPublicMessageDetails, body, { headers });
  }

  public getPublicMessageAttachment(username: string, attachmentID: string): Observable<any> {
    const httpOptions = {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json',
        })
    };

    const body = {
      Username: username,
      AttachmentID: attachmentID 
    };

    return this.http.post<any>(ServiceUrls.GetPublicMessageAttachment, body, httpOptions);
  }

  public updateNotificationStatus(username: string, publicMessageID: string, newStatus: string): Observable<any> {
      const headers = new HttpHeaders({
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json'
      });

      const body = {
        Username: username,
        PublicMessageID: publicMessageID,
        NewStatus: newStatus
      };

      return this.http.post<any>(ServiceUrls.UpdatePublicMessage, body, { headers });
    }
}