export interface UserRegistry {
  id?: number;
  nome: string;
  cognome: string;
  username?: string;
  password?: string;
  codice_fiscale: string;
  email?: string;
  matricola?: string;
  qualifica: string;
  badge: string;
  badge2: string;
  abilitatore?: boolean;
  azienda?: string;
	fonte?: string;
  attivo?: boolean;
  app?: boolean;
  webapp?: boolean;
  centrale_operativa?: string;
  pronto_soccorso?: string;
  scadenza_password?: string;
  ultimo_cambio_password?: string;
}