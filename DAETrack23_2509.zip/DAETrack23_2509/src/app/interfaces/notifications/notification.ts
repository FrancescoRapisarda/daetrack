// Interfaccia per la risposta complessiva
export interface DAEPublicMessagesResponse {
    DAEPublicMessages: DAEPublicMessageGroup[]
  }
  // Interfaccia per ogni gruppo DAE
  export interface DAEPublicMessageGroup {
    ID_DAE: string,
    Address: string,
    PublicMessages: PublicMessage[]
  }
  // Interfaccia per i messaggi pubblici
  export interface PublicMessage {
    ID_PublicMessage: string,
    Notes: string,
    Date: string,
    Status: string
  }
  
  export interface DAESelectedPublicMessageResponse {
    DAESelectedPublicMessage: PublicMessageDetails[]
  }
  
  export interface PublicMessageDetails{
      PublicMessageID: string,
      PublicMessageNotes: string,
      PublicMessageDate: string,
      PublicMessageStatus: string,
      DAEAddress:string,
      DAEBrand: string,
      DAECodeNumber:string, //potrebbe essere un numero
      DAELatitude: string,
      DAELongitude: string,
      DAEModel: string,
      DAEPositionDescription: string,
      DAEStatus:string,
      Pictures: Pictures[]
  
  }
  export interface Pictures{
      ID: string,
      Filename: string,
      Length: string
  }