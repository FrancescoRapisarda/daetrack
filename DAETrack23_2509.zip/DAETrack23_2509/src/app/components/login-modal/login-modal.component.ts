import { CommonModule } from '@angular/common';
import { Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClient, HttpClientModule, HttpResponse } from '@angular/common/http';
import { AuthService } from '../../services/authentication/auth.service';

import * as StatusMessages from '../../common/constants/status-messages';
import { LoginResponse } from '../../interfaces/authentication/login-response';

@Component({
  selector: 'app-login-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule,TranslateModule, HttpClientModule],
  templateUrl: './login-modal.component.html',
  styleUrl: './login-modal.component.scss',
})
  
export class LoginModalComponent implements OnInit{
  loginObj: any = {
    "UsernameOrEmail": '',
    "Password": ''
  }
  isLoggedIn: boolean = false;
  user: any;
  warningMessage: boolean = false;
  warningMessageText: string = '';
  waitingResp: boolean = false;
  loadingSpinner: boolean = false;
  
  http = inject(HttpClient);

  constructor(private router: Router, private authService: AuthService) {}
  
  @Input() isOpenLogin = false;
  @Output() closeModal = new EventEmitter<void>();
  @Output() loginSuccess = new EventEmitter<{ firstName: string, lastName: string, role: string }>();
  @Output() logout = new EventEmitter<void>();

  ngOnInit(): void {
    this.authService.currentToken.subscribe(token => {
      (token !== '') ? this.isLoggedIn = true : this.isLoggedIn = false;
    })
    /*
    if(this.authService.getToken() !== null){
      console.log('token yes');
      this.isLoggedIn = true;
    }*/
  }
  
  openLoginModal() {
    this.isOpenLogin = true;
  }

  closeLoginModal() {
    this.isOpenLogin = false;
    this.closeModal.emit();
  }  
   
  onLogout() {
    //this.authService.removeToken();
    this.authService.setToken('');
      
    this.isLoggedIn = false;
    this.user = null;
    this.logout.emit();  
    this.closeLoginModal(); 
  }

  onUserLogin() {
    this.waitingResp = true;  
    
    if (this.warningMessage === true) {
      this.warningMessage = false
    }
    
    this.loadingSpinner = true;
    
    this.authService.login(this.loginObj.UsernameOrEmail, this.loginObj.Password).subscribe((response: HttpResponse<LoginResponse>) => {
      // const headers = response.headers;
      this.user = response.body;
      this.user.Phone = "+49 327 8761 474";

      this.loadingSpinner = false;
      
      if (response) {
        //alert("Login Success");
        this.isLoggedIn = true;
        // this.router.navigateByUrl('login');
        // this.router.navigateByUrl('siderbar');
       } else {
          alert("Check User Mail or Password");
       }
    }, (error) => {
      //Unauthorized
      if (error.status === 401) {
        this.warningMessageText = StatusMessages.DialogWrongUsernameError;
        this.warningMessage = true;
        this.loginObj.Password = "";
      } else {
        this.warningMessageText = StatusMessages.DialogServerNotReachableError;
        this.warningMessage = true;
      }
      this.waitingResp = false;
    });
  } 
}
