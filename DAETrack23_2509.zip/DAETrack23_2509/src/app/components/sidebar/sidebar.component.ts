import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccordionComponent } from "../accordion/accordion.component";
import { TranslateModule } from '@ngx-translate/core';
import { AuthService } from '../../services/authentication/auth.service';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, TranslateModule, AccordionComponent],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss'
})
export class SidebarComponent implements OnInit{
  @Input() isLoggedIn: boolean = false;  
  @Input() isOpen!: boolean;
  @Output() isOpenChange = new EventEmitter<boolean>();

  constructor(private authService: AuthService){}

  ngOnInit(): void {
    this.authService.currentToken.subscribe(token => {
      (token !== '') ? this.isLoggedIn = true : this.isLoggedIn = false;
    })
  }

  closeSidebar(): void {
    this.isOpen = false;
    this.isOpenChange.emit(this.isOpen);
  }
}
