import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { SidebarComponent } from "../sidebar/sidebar.component";
import { LoginModalComponent } from "../login-modal/login-modal.component";
import { LocationService } from '../../services/location.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, TranslateModule,RouterModule,FormsModule,SidebarComponent, LoginModalComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
public isSidebarOpen: boolean = false;
  public isBlueIconLogin: boolean = false;  
  public isModalOpen: boolean = false; 
  public user: { firstName: string, lastName: string, role: string } | null = null;

  isSubmitted: boolean = false;
  searchedAddress: string = '';
  addressesArray: Array<any> = [];

  constructor(private translate: TranslateService, private locationService: LocationService){}

  public changeLang(lang: string): void {
    this.translate.use(lang);
  }

  public onSubmit(): void{
    const searchBarInput = document.querySelector('.search-bar-input input') as HTMLElement;
    searchBarInput.style.borderBottomLeftRadius = '0';
    searchBarInput.style.borderBottomRightRadius = '0';

    const searchForm = document.querySelector('#searchForm input') as HTMLInputElement;
    this.searchedAddress = searchForm.value;

    this.locationService.getAddress(this.searchedAddress).subscribe((response: any) => {
      this.addressesArray = response;

      this.isSubmitted = !this.isSubmitted;
    });
  }

  public onAddressClick(selectedAddress: any): void{
    this.locationService.updateAdress(selectedAddress);
    this.isSubmitted = !this.isSubmitted;

    const searchBarInput = document.querySelector('.search-bar-input input') as HTMLElement;
    searchBarInput.style.borderBottomLeftRadius = '30px';
    searchBarInput.style.borderBottomRightRadius = '30px';

    const resultsContainer = document.getElementById('results-container') as HTMLElement;
    resultsContainer.style.display = 'none';
  }
  
  public onLogout() {
    this.user = null; 
  }
  
  public toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
  }

  public openModal() {
    if (!this.isModalOpen) {
      this.isModalOpen = true;
      this.isBlueIconLogin = true;  // Cambia icona in blu
    }
  }
  
  public closeModal() {
    this.isModalOpen = false;   // Imposta modale come chiusa
    this.isBlueIconLogin = false;    // Cambia icona in nero
  }
  
  // Metodo per gestire l'evento di login riuscito
  public handleLoginSuccess(user: { firstName: string, lastName: string, role: string }) {
    this.user = user;
  }
}