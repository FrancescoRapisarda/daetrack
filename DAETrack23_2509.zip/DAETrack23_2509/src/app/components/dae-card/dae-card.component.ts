import { Component, Input, OnInit } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import { DAEparams } from '../../interfaces/dae/DAEparams';
import { AuthService } from '../../services/authentication/auth.service';

@Component({
  selector: 'app-dae-card',
  standalone: true,
  imports: [TranslateModule, CommonModule],
  templateUrl: './dae-card.component.html',
  styleUrl: './dae-card.component.scss'
})
export class DaeCardComponent implements OnInit{
  @Input() data!: DAEparams; 
  @Input() notifications: any[] = [];
  @Input() selectedMarker!: HTMLElement;

  isLogged: boolean = false;
  isNotificationsEnabled: boolean = this.isLogged;

  constructor(private authService: AuthService){}

  ngOnInit(): void {
    this.authService.currentToken.subscribe(token => {
      /*if(token !== '')
        this.isLogged = true;
      else{
        this.isLogged = false;
        console.log(this.notifications);
        this.notifications = [];
      }*/
      (token !== '') ? this.isLogged = true : this.isLogged = false;
    })
  }

  closeCard(){
    const DAEcard = document.querySelector('.dae-card') as HTMLElement;
    DAEcard.classList.add('dae-card-hidden');

    // The marker returns to it's original style
    this.selectedMarker.style.width = "45px";
    this.selectedMarker.style.height = "35px";
    this.selectedMarker.style.border = "none";
    this.selectedMarker.style.borderRadius = "0";
  }
}