import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { NotificationService } from '../../services/notification.service';
import { CommonModule } from '@angular/common';
import { MatExpansionModule } from '@angular/material/expansion';
//import { SegnalationCardComponent } from '../segnalation-card/segnalation-card.component';
import { MatDialog } from '@angular/material/dialog';
import { DAEPublicMessagesResponse, DAEPublicMessageGroup, PublicMessageDetails } from '../../interfaces/notifications/notification';

@Component({
  selector: 'app-notification',
  standalone: true,
  imports: [CommonModule, MatExpansionModule],
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent implements OnInit {
  DAEPublicMessagesList: DAEPublicMessageGroup[] = [];

  constructor(
    public dialogRef: MatDialogRef<NotificationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private notificationService: NotificationService,
    private dialog: MatDialog // Aggiungi il servizio MatDialog
  ) {}

  ngOnInit(): void {
    this.loadNotifications();
  }

  loadNotifications(): void {
    const username = 'gstretti';
    const status = 'OPEN';

    this.notificationService.getNotifications(username, status).subscribe((response: DAEPublicMessagesResponse) => {
      this.DAEPublicMessagesList = response.DAEPublicMessages;
      console.log(this.DAEPublicMessagesList);
    });
  }

  onMessageClick(message: any): void {
    const username = 'gstretti'; 
    const id = message.ID_PublicMessage;

    this.notificationService.getPublicMessageDetails(username, id).subscribe((response: PublicMessageDetails) => {
      this.close();
      //this.openSegnalationCard(response);
      console.log(response);
      //this.notificationService.updateNotifications(response);
    });
  }

  openSegnalationCard(messageDetails: PublicMessageDetails): void {
  console.log('Message Details:', messageDetails); 
  /*const dialogRef = this.dialog.open(SegnalationCardComponent, {
    data: messageDetails,
  });*/
}

  close(): void {
    this.dialogRef.close();
  }
}
