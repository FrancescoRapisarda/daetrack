// User roles constants
export const Supervisore = 'SUPERVISORE';
// export const SupervisoreCO = 'SUPERVISORE_CO';
// export const Medico = 'MEDICO';
// export const Infermiere = 'INFERMIERE';
// export const AutistaSoccorritore = 'AUTISTA_SOCCORRITORE';
// export const MedicoPS = 'MEDICO_PS';
// export const Operatore = 'OPERATORE';
export const UtentePRO = 'UTENTE_PRO';