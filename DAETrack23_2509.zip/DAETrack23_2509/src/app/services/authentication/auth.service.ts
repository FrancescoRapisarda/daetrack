import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { LoginResponse } from '../../interfaces/authentication/login-response';

import * as ServiceUrls from "../../common/constants/service-urls";

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private tokenSouce = new BehaviorSubject<string>(''); //<string | null>(null)
  currentToken = this.tokenSouce.asObservable();

  constructor(private http: HttpClient) {}

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'RequestSource': 'Web' 
    })
  };
  
  public setName(name: string): void {
    localStorage.setItem("completeName", name);
  }

  public getName(): string | null {
    return localStorage.getItem("completeName");
  }
  
  public setInitials(name: string, surname: string): void {
    const initials = name.charAt(0).toUpperCase() + surname.charAt(0).toUpperCase();
    localStorage.setItem("initials", initials);
  }

  public getInitials(): string | null {
    return localStorage.getItem("initials");
  }
  
  public getToken(): string | null {
    return localStorage.getItem('dae_data');
  }
  
  public setToken(token: string): void {
    this.tokenSouce.next(token);
    localStorage.setItem('dae_data', token);
  }
  
  public removeToken(): void {
    localStorage.removeItem('dae_data');
  }

  public login(usernameOrEmail: string, password: string): Observable<HttpResponse<LoginResponse>> {
    const loginData = {
      UsernameOrEmail: usernameOrEmail,
      Password: password
    };

    return this.http.post<LoginResponse>(ServiceUrls.Login, loginData, { ...this.httpOptions, observe: 'response' }).pipe(
      map(response => {
        // Save the token
        let token = response.headers.get("Authorization");
        
        if(token !== null)
          this.setToken(token);
        
        return response;
      })
    );
  }  
}
