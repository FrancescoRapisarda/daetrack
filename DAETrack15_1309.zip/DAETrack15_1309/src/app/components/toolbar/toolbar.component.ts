import { Component, EventEmitter, Output } from '@angular/core';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatButtonModule} from '@angular/material/button';
import {MatBadgeModule} from '@angular/material/badge';
import {MatIconModule} from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { FilterComponent } from '../filter/filter.component';
import { Input } from '@angular/core';
import { activeStatus } from '../../common/constants/constants';

@Component({
  selector: 'toolbar',
  standalone: true,
  imports: [MatButtonModule, MatBadgeModule, MatButtonToggleModule, MatIconModule, MatToolbarModule, FilterComponent],
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.scss']
})
export class ToolbarComponent {
  notificationsCount: number = 2;
  alertsEnabled: boolean = true;
  isFilterOpen: boolean = false;
  @Input() status!: string;
  @Output() statusChange = new EventEmitter<string>();

  openAlerts(): void {
    this.alertsEnabled = !this.alertsEnabled;
    console.log(`Le notifiche sono ora ${this.alertsEnabled ? 'abilitate' : 'disabilitate'}`);
  }

  openFilter(): void {
    this.isFilterOpen = !this.isFilterOpen;
    console.log(this.isFilterOpen);

    console.log(this.status);
    this.statusChange.emit(this.status);
    console.log('filter status ' + this.status);
  }

  openSettings(): void {
    console.log('Impostazioni aperte!');
  }
}
