export interface DAEdata{
    latitude: number,
    longitude: number,
    distance: number,
    status: string
}