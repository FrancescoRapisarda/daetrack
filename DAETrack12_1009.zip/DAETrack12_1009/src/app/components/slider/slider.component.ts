import {Component, EventEmitter, Output} from '@angular/core';
import {MatSliderModule} from '@angular/material/slider';

@Component({
  selector: 'app-slider',
  standalone: true,
  imports: [
    MatSliderModule
  ],
  templateUrl: './slider.component.html',
  styleUrl: './slider.component.scss'
})
export class SliderComponent {
  @Output() mouseup = new EventEmitter<number>();
  
  max = 10000;
  min = 100;
  step = 100;
  value = 100;

  formatLabel(value: number): string {
    if(value < 1000)
      return value + 'm';
    else
      return (value / 1000) + 'km';
  }
}