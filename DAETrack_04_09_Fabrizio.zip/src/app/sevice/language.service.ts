import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LanguageService {

  private readonly languageKey = 'selectedLanguage';

  constructor() { }

  // Imposta la lingua selezionata
  setLanguage(language: string): void {
    localStorage.setItem(this.languageKey, language);
  }

  // Recupera la lingua selezionata
  getLanguage(): string | null {
    return localStorage.getItem(this.languageKey);
  }

  // Controlla se una lingua è stata selezionata
  hasLanguage(): boolean {
    return this.getLanguage() !== null;
  }

  // Rimuove la lingua alla fine della sessione
  clearLanguage(): void {
    localStorage.removeItem(this.languageKey);
  }
}
