import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import * as ServiceUrls from '../common/constants/service-urls';


@Injectable({
  providedIn: 'root',
})
export class NotificationService {
  private apiUrl = 'http://10.172.37.19:5055/api/Notifications/GetAllPublicMessages';
  private token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6Im1yb3NzaSIsIm5iZiI6MTcyNzA4OTI5MSwiZXhwIjoxNzMwNjg5MjkxLCJpYXQiOjE3MjcwODkyOTF9.F8-OrOH75d_tyqiinvJ2Vc2k4mSY9JihpgLU4EqRh4o';

  private notificationsCount = new BehaviorSubject<number>(0);
  notificationsCount$ = this.notificationsCount.asObservable();

  /* To share data with the dae-card
  private notificationSource = new BehaviorSubject<any>(null);
  currentNotification = this.notificationSource.asObservable();*/

  constructor(private http: HttpClient) {}

  public getNotifications(username: string, status: string): Observable<any> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.token}`,
      'Content-Type': 'application/json'
    });

    const body = {
      Username: username,
      Status: status
    };

    return this.http.post<any>(this.apiUrl, body, { headers });
  }
  
  public getPublicMessageDetails(username: string, ID_PublicMessage: string): Observable<any> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.token}`,
      'Content-Type': 'application/json'
    });

    const body = {
      Username: username,
      PublicMessageID: ID_PublicMessage
    };

    return this.http.post<any>(ServiceUrls.GetPublicMessageDetails, body, { headers });
  }

  /*
  public updateNotifications(newNotification: any){
    this.notificationSource.next(newNotification);
  }*/
}

/*
 TEST GET CON PARAMETRI


getPublicMessageDetails(username: string, ID_PublicMessage: string): Observable<any> {
  // Definizione delle opzioni HTTP
  const httpOptions = {
    headers: new HttpHeaders({
      'Authorization': `Bearer ${this.token}`,
      'Content-Type': 'application/json'
    }),
    params: {
      Username: username,
      PublicMessageID: ID_PublicMessage
    }
  };

  // Stampa dei valori per il debug
  console.log('Servizio:', httpOptions.params.Username, httpOptions.params.PublicMessageID);

  // Esegui la richiesta GET con i parametri passati come query e headers
  return this.http.get<any>(ServiceUrls.GetPublicMessageDetails, httpOptions);
}


*/

/*
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class NotificationService {
  // Lista delle notifiche
  private notifications = [
    { idDAE: '89r23', title: 'Via Acicastello 71, Aci castello CT', message: 'Danneggiato', time: '15/09/2024 12:58:00' },
    { idDAE: '89r23', title: 'Via Acicastello 71, Aci castello CT', message: 'Mancante', time: '18/08/2024 12:00:00' },
    { idDAE: 'PSq34', title: 'Via Etnea 145, Catania CT', message: 'Vandalizzato', time: '13/06/2024 10:00:00' },
    { idDAE: 'jcksdjbvs33', title: 'Via Oliva S. Mauro 16, Aci castello CT', message: 'Esploso.', time: '18/09/2024 07:00:00' },
    { idDAE: 'Luk3$0n0tu0p4dr3', title: 'Luna oceanica 1, Kef Bir', message: 'Distrutto dai ribelli', time: '18/09/2024 08:44:00' },
    { idDAE: '3reb', title: 'Viale della regione 70, Palermo PA', message: 'Istruzioni solo in Palermitano', time: '17/09/2024 12:00:00' },
  ];

  private notificationsCount = new BehaviorSubject<number>(this.notifications.length);
  notificationsCount$ = this.notificationsCount.asObservable();

  constructor(private http: HttpClient) {}

  getNotifications() {
    return this.notifications;
  }

  removeNotification(index: number) {
    this.notifications.splice(index, 1);
    this.notificationsCount.next(this.notifications.length);
  }

}


*/