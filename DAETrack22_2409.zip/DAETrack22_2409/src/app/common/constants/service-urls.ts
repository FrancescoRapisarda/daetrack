import { environment } from "../../../environments/environment";

export const Login = environment.backendAddress + '/api/Authentication/Login';

export const GetDAEByDistance = environment.backendAddress + '/api/DAE/GetDAEByDistance';

export const SearchAddress = 'https://nominatim.openstreetmap.org/search?';

export const GetAllPublicMessages = environment.backendAddress + '/api/Notification/GetAllPublicMessages';
export const GetPublicMessageDetails = environment.backendAddress + '/api/Notifications/GetPublicMessageDetails';
export const GetPublicMessageAttachment = environment.backendAddress + '/api/Notification/GetPublicMessageAttachment';
export const UpdatePublicMessage = environment.backendAddress + '/api/Notification/UpdatePublicMessage';