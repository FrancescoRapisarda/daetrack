import { AfterContentInit, AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { CommonModule } from '@angular/common';
import { DAEparams } from '../../interfaces/dae/DAEparams';

@Component({
  selector: 'app-dae-card',
  standalone: true,
  imports: [TranslateModule, CommonModule],
  templateUrl: './dae-card.component.html',
  styleUrl: './dae-card.component.scss'
})
export class DaeCardComponent implements OnInit, AfterViewInit{
  @Input() data!: DAEparams; 
  @Input() notifications: any[] = [];
  @Input() selectedMarker!: HTMLElement;

  isLoggedIn: boolean = true;

  constructor(){}

  ngOnInit(): void {
    console.log(this.notifications);
  }

  ngAfterViewInit(): void {
    console.log(this.notifications);
  }

  closeCard(){
    const DAEcard = document.querySelector('.dae-card') as HTMLElement;
    DAEcard.classList.add('dae-card-hidden');

    // The marker returns to it's original style
    this.selectedMarker.style.width = "45px";
    this.selectedMarker.style.height = "35px";
    this.selectedMarker.style.border = "none";
    this.selectedMarker.style.borderRadius = "0";
  }
}