import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-accordion',
  standalone: true,
  imports: [CommonModule,TranslateModule],
  templateUrl: './accordion.component.html',
  styleUrl: './accordion.component.scss'
})
export class AccordionComponent {
   accordionItems = [
    { icon: 'daetrack-icon', title: 'DAE', content: 'Contenuto della sezione 1.', isOpen: false },
    { icon: 'daetrack-trained-people', title: 'trainedPeople', content: 'Contenuto della sezione 2.', isOpen: false },
    { icon: 'daetrack-training-bodies', title: 'trainingBodies', content: 'Contenuto della sezione 3.', isOpen: false },
    { icon: 'daetrack-trainers', title: 'instructors', content: 'Contenuto della sezione 4.', isOpen: false },
  ];

  toggleAccordion(index: number) {
    this.accordionItems.forEach((item, i) => {
      if (i === index) {
        item.isOpen = !item.isOpen;
      } else {
        item.isOpen = false; // Chiudo tutte le altre sezioni
      }
    });
  }
}
