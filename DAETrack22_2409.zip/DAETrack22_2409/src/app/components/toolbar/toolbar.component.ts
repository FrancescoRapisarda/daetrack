
import { Component, EventEmitter, Output, Input, OnInit, OnDestroy } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { FilterComponent } from '../filter/filter.component';
import { NotificationComponent } from '../notification/notification.component';
import { NotificationService } from '../../services/notification.service';
import { Subscription } from 'rxjs';
import { MatButtonModule } from '@angular/material/button';
import { MatBadgeModule } from '@angular/material/badge';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';

@Component({
  selector: 'toolbar',
  standalone: true,
  imports: [MatButtonModule, MatBadgeModule, MatButtonToggleModule, MatIconModule, MatToolbarModule, MatDialogModule, FilterComponent],
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.scss']
})
export class ToolbarComponent implements OnInit, OnDestroy {
  notificationsCount: number = 0;
  alertsEnabled: boolean = true;
  @Input() isFilterOpen: boolean = false;
  @Input() status!: string;
  @Output() statusChange = new EventEmitter<string>();

  private notificationsSubscription!: Subscription;

  constructor(private dialog: MatDialog, private notificationService: NotificationService) {}

  ngOnInit(): void {
    // Sottoscriviti al conteggio delle notifiche dal servizio
    this.notificationsSubscription = this.notificationService.notificationsCount$.subscribe(count => {
      this.notificationsCount = count;
    });
  }

  ngOnDestroy(): void {
    // Unsubscribe per evitare memory leaks
    if (this.notificationsSubscription) {
      this.notificationsSubscription.unsubscribe();
    }
  }

  public onUpdateStatus(status: string): void {
    this.status = status;
    this.statusChange.emit(this.status);
  }

  public openNotification(): void {
    this.dialog.open(NotificationComponent, {
      width: '400px',
      height: '600px',
      data: { notificationsCount: this.notificationsCount }
    });
  }

  public openFilter(): void {
    this.isFilterOpen = !this.isFilterOpen;
  }

  public openSettings(): void {
    console.log('Impostazioni aperte!');
  }
}
