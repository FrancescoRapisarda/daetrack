import { Component, EventEmitter, Input, Output } from '@angular/core';
import { activeStatus, allStatus, inactiveStatus } from '../../common/constants/constants';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-filter',
  standalone: true,
  imports: [TranslateModule],
  templateUrl: './filter.component.html',
  styleUrl: './filter.component.scss'
})
export class FilterComponent {
  @Input() status: string = activeStatus;
  @Input() isFilterOpen!: boolean;
  @Output() filterStatusChange = new EventEmitter<string>();
  @Output() isFilterOpenChange = new EventEmitter<boolean>();
  
  public showActiveDAE(){
    this.status = activeStatus;
    this.filterStatusChange.emit(this.status);

    // to avoid displaying the filter
    this.isFilterOpenChange.emit(!this.isFilterOpen);
  }

  public showInctiveDAE(){
    this.status = inactiveStatus;
    this.filterStatusChange.emit(this.status);

    this.isFilterOpenChange.emit(!this.isFilterOpen);
  }

  public showAllDAE(){
    this.status = allStatus;
    this.filterStatusChange.emit(this.status);

    this.isFilterOpenChange.emit(!this.isFilterOpen);
  }
}
