export const environment = {
    production: true,
    apiKey: 'OPEfAKkldeAZ6hRP0N0p',
    backendAddress: 'http://10.172.37.19:5055'
  };
  