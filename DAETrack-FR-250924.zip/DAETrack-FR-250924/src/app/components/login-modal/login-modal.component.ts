import { CommonModule } from '@angular/common';
import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClient, HttpClientModule, HttpResponse } from '@angular/common/http';
import { AuthService } from '../../services/authentication/auth.service';

import * as StatusMessages from '../../common/constants/status-messages';
import { LoginResponse } from '../../interfaces/authentication/login-response';

@Component({
  selector: 'app-login-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule,TranslateModule, HttpClientModule],
  templateUrl: './login-modal.component.html',
  styleUrl: './login-modal.component.scss',
})
  
export class LoginModalComponent {
  loginObj: any = {
    usernameOrEmail: '',
    password: ''
  }
  isLoggedIn: boolean = false;
  user: any;
  warningMessage: boolean = false;
  warningMessageText: string = '';
  waitingResp: boolean = false;
  loadingSpinner: boolean = false;
  
  constructor(private router: Router,
              private authService: AuthService) {
  }
  
  @Input() isOpenLogin = false;
  @Output() closeModal = new EventEmitter<void>();

  openLoginModal() {
    this.isOpenLogin = true;
  }

  closeLoginModal() {
    this.isOpenLogin = false;
    this.closeModal.emit();
  }  
   
  
  onUserLogin() {
    this.waitingResp = true;  
    
    if (this.warningMessage === true) {
      this.warningMessage = false
    }
    
    this.loadingSpinner = true;
    
    this.authService.login(this.loginObj.usernameOrEmail, this.loginObj.password).subscribe({
      next: response => {
        this.user = response;
        this.user.Phone = "+49 327 8761 474";

        this.loadingSpinner = false;
        
        if (response) {
          this.isLoggedIn = true;
        } else {
            alert("Check User Mail or Password");
        }
      }, 
      error: (error) => {
        //Unauthorized
        if (error.status === 401) {
          this.warningMessageText = StatusMessages.DialogWrongUsernameError;
          this.warningMessage = true;
          this.loginObj.password = "";
        } else {
          this.warningMessageText = StatusMessages.DialogServerNotReachableError;
          this.warningMessage = true;
        }
        this.waitingResp = false;
      }
    });
  }

  onLogout() {
    //this.authService.getData();
    this.authService.logout();
    this.closeLoginModal(); 
    this.isLoggedIn = false;
  }
  
}
