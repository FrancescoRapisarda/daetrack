import { Component, EventEmitter, Input, Output } from '@angular/core';
import { activeStatus, allStatus, inactiveStatus } from '../../common/constants/constants';

@Component({
  selector: 'app-filter',
  standalone: true,
  imports: [],
  templateUrl: './filter.component.html',
  styleUrl: './filter.component.scss'
})
export class FilterComponent {
  @Input() filterStatus: string = activeStatus;
  @Output() filterStatusChange = new EventEmitter<string>();
  
  public showActiveDAE(){
    //const dropdown = document.querySelector('#filter') as HTMLElement;
    //dropdown.classList.add('hidden');
    this.filterStatus = activeStatus;
    this.filterStatusChange.emit(this.filterStatus);
    console.log('active ' + this.filterStatus);
  }

  public showInctiveDAE(){
    this.filterStatus = inactiveStatus;
    this.filterStatusChange.emit(this.filterStatus);
    console.log('inactive ' + this.filterStatus);
  }

  public showAllDAE(){
    this.filterStatus = allStatus;
    this.filterStatusChange.emit(this.filterStatus);
    console.log('all ' + this.filterStatus);
  }
}
