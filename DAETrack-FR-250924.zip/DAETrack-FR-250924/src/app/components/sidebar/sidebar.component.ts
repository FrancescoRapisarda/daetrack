import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccordionComponent } from "../accordion/accordion.component";
import { TranslateModule } from '@ngx-translate/core';
import { AuthService } from '../../services/authentication/auth.service';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, TranslateModule, AccordionComponent],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss'
})
export class SidebarComponent{
  isLoggedIn: boolean = false;
  // @Input() isLoggedIn: boolean = false;  // Stato di login passato dal componente genitore
  @Input() isOpen!: boolean;
  @Output() isOpenChange = new EventEmitter<boolean>();
  
  constructor(private authService: AuthService) {
    this.authService.isLoggedIn.subscribe(loggedIn => {
      this.isLoggedIn = loggedIn;
    });
  }

  closeSidebar(): void {
    this.isOpen = false;
    // this.isOpenChange.emit(this.isOpen);
  }
  
  onLogout() {
    this.authService.logout();
  }
}
