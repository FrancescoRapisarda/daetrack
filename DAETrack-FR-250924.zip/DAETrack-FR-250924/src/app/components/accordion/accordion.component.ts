import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-accordion',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './accordion.component.html',
  styleUrl: './accordion.component.css'
})
export class AccordionComponent {
   accordionItems = [
    { img: 'assets/icons/DAEicon.png', title: 'DAE', content: 'Contenuto della sezione 1.', isOpen: false },
    { img: 'assets/icons/trained-people.png', title: 'Persone Formate', content: 'Contenuto della sezione 2.', isOpen: false },
    { img: 'assets/icons/training-bodies.png', title: 'Enti Formatori', content: 'Contenuto della sezione 3.', isOpen: false },
    { img: 'assets/icons/trainers.png', title: 'Istruttori', content: 'Contenuto della sezione 4.', isOpen: false },
  ];

  toggleAccordion(index: number) {
    this.accordionItems.forEach((item, i) => {
      if (i === index) {
        item.isOpen = !item.isOpen;
      } else {
        item.isOpen = false; // Chiudo tutte le altre sezioni
      }
    });
  }
}
