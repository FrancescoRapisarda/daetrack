import { UserRegistry } from "../registries/user-registry";

export interface LoginResponse {
  Name: string;
  Lastname: string;
  Username: string;
  FiscalCode: string;
  Email: string;
  Role: string;
}