import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Router } from "@angular/router";
import { AuthService } from '../authentication/auth.service';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import * as ServiceUrls from '../../common/constants/service-urls';

@Injectable({
  providedIn: 'root'
})
export class ErrorInterceptorService implements HttpInterceptor {
  constructor(private router: Router,
              private authService: AuthService) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        // Unauthorized
        if (error.status === 401 && error.url != ServiceUrls.Login && error.url != ServiceUrls.SetPassword) {
          // Temporarily save the current unauthorized/expired token
          let token = this.authService.getToken();
          
          setTimeout(() => {
            // NOTE: If the current token is different than the one that initiated
            //       the "force logout" procedure, it means that the user logged in again.
            //       In this case don't kick him out.
            if (this.authService.getToken() === token) {
              // Remove the token
              this.authService.removeToken();

              // Go to the login page
              this.router.navigate(['/login']);
            }
          }, 5000);
        }

        return throwError(error);
      })
    );
  }
}
