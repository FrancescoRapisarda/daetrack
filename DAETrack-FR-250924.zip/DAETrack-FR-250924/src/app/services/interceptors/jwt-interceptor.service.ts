import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { AuthService } from '../authentication/auth.service';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class JwtInterceptorService implements HttpInterceptor {
  constructor(private authService: AuthService) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    //Add the authorization if a token is present
    const localToken = this.authService.getToken();
    
    if (localToken) {
      request = request.clone({
        setHeaders: {
          Authorization: localToken,
        }
      });
    }
    return next.handle(request);
  }
}