import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JwtHelperService } from "@auth0/angular-jwt";
import { BehaviorSubject, map, Observable, Subject } from 'rxjs';
import { LoginResponse } from '../../interfaces/authentication/login-response';

import * as ServiceUrls from "../../common/constants/service-urls";

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private jwtHelper: JwtHelperService;
  private isLoggedInSubject: BehaviorSubject<boolean>;

  isLoggedIn: Observable<boolean>;
  
  constructor(private http: HttpClient) {
    this.jwtHelper = new JwtHelperService();
    this.isLoggedInSubject = new BehaviorSubject(false);
    this.isLoggedIn = this.isLoggedInSubject.asObservable();
  }

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'RequestSource': 'Web' 
    })
  };
  
  setIsLoggedIn(isLoggedIn: boolean) {
    return this.isLoggedInSubject.next(isLoggedIn);
  }
  
  getUsername(): string | null {
    let username: string;
    let token = this.getToken();
    
    if (token) {
      let decodedToken = this.jwtHelper.decodeToken(token);
      username = decodedToken.unique_name;
    }
    
    return sessionStorage.getItem("completeName");
  }
  
  getToken(): string | null {
    return sessionStorage.getItem('dae_data');
  }
  
  setToken(token: string | null): void {
    if (token) {
      sessionStorage.setItem('dae_data', token);
      this.setIsLoggedIn(true);  // Imposto stato di autenticazione come loggato
    }
  }
  
  removeToken(): void {
    sessionStorage.removeItem('dae_data');
    this.setIsLoggedIn(false);  // Imposto stato come non loggato
  }
  
  login(usernameOrEmail: string, password: string): Observable<LoginResponse> {
    const loginData = {
      UsernameOrEmail: usernameOrEmail,
      Password: password
    };
    
    return this.http.post<LoginResponse>(ServiceUrls.Login, loginData, { ...this.httpOptions, observe: 'response' }).pipe(
      map(response => {
        // Get the token from the "Authorization" header
        let token = response.headers.get("Authorization");
        
        if (token) {
          // Store the token into session storage
          this.setToken(token);
        } else {
          throw new Error("Token is null");
        }
        
        return <LoginResponse>response.body;
      })
    );
  }
  
  logout() {
    this.removeToken();
  }
}
