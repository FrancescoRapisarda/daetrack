import { environment } from "../../../environments/environment";

export const GetDAEByDistance = environment.backendAddress + '/api/DAE/GetDAEByDistance';

export const Login = environment.backendAddress + '/api/Authentication/Login';