// Page status error messages
export const PageUnauthorizedError = "Non sei autorizzato ad effettuare l'operazione. Verrai rediretto alla pagina di login";
export const PageServerRetrieveError = "Errore nel recuperare i dati dal server. Riprovare tra qualche minuto";
export const PageServerSendError = "Errore nell'invio dei dati al server. Riprovare tra qualche minuto";
export const PageWrongOldPasswordError = "La vecchia password inserita non è corretta.</br>Verrai rediretto alla pagina di login";
export const PageNoCardIdFoundError = "Identificativo scheda non specificato. Verrai rediretto alla pagina degli interventi"

// DEMO
export const PageNoPatientIdFoundError = "Identificativo paziente non specificato. Verrai rediretto alla pagina dei pazienti"

// Dialog status success messages
export const DialogPasswordChangedSuccess = "Modifica effettuata con successo.</br>Verrai rediretto alla pagina di login";
export const DialogPasswordSetSuccess = "Password impostata con successo";
export const DialogPasswordResetSuccess = "Richiesta inviata con successo";

// Dialog status error messages
export const DialogUnauthorizedError = "Non sei autorizzato ad effettuare l'operazione.</br>Verrai rediretto alla pagina di login";
export const DialogUnauthorizedNoRedirectError = "Non sei autorizzato ad effettuare l'operazione";
export const DialogServerRetrieveError = "Errore nel recuperare i dati dal server.</br>Riprovare tra qualche minuto";
export const DialogServerSendError = "Errore nell'invio dei dati al server.</br>Riprovare tra qualche minuto";
export const DialogServerNotReachableError = "Errore nel contattare il server.</br>Riprovare tra qualche minuto";
export const DialogWrongUsernameError = "Nome utente inesistente";
export const DialogWrongUserOrPasswordError = "Nome utente o password errati";
export const DialogUserRoleNotAuthorizedError = "L'utente con questo ruolo non è autorizzato ad accedere";

// General validation error messages
export const TaxCodeValidationError = "Errore di validazione: Codice Fiscale già esistente";
export const EmailAlreadyExistValidationError = "Errore di validazione: E-mail già esistente";
export const UsernameAlreadyExistValidationError = "Errore di validazione: Username già esistente";
export const GeneralAddUserValidationError = "Errore di validazione. Impossibile inserire l'utente";
export const GeneralEnableUserValidationError = "Errore di validazione. Impossibile abilitare l'utente";