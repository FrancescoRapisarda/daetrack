import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DAEparams } from '../interfaces/DAEparams';
import { DAEdata } from '../interfaces/DAEdata';
import * as ServiceUrls from '../common/constants/service-urls';

@Injectable({
  providedIn: 'root'
})
export class DaeService {
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      "RequestSource": "web" 
    })
  }

  constructor(private http: HttpClient) { }

  public getDAEByDistance(daeData: DAEdata): Observable<any>{
    const data = {
      "StartingPoint":
      {
          "Latitude": daeData.latitude,
          "Longitude": daeData.longitude
      },
      "Distance": daeData.distance,
      "Status": daeData.status
    }

    return this.http.post<any>(ServiceUrls.GetDAEByDistance, data, this.httpOptions);
  }
}
