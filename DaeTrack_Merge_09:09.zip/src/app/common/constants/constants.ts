// Dae data
export const defaultDistance = 2000;
export const activeStatus = "ACTIVE";
export const inactiveStatus = "INACTIVE";