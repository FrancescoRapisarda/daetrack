import { UserRegistry } from "../registries/user-registry";

export interface LoginResponse {
  message: string;
  user: UserRegistry;
  token: string;
}