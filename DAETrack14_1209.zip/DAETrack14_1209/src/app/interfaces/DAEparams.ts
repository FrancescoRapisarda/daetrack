export interface DAEparams{
    ID: string,
    Brand: string,
    Model: string,
    CodeNumber: string,
    Address: string,
    PositionDescription: string,
    Latitude: string,
    Longitude: string,
    Status: string,
    LastMaintenance?: string,
    nextMaintenance?: string, 
    Notes?: string
}