// Dae data
export const defaultDistance = 2000;
export const defaultLatitude = 37.4922300;
export const defaultLongitude = 15.0704100;
export const activeStatus = "ACTIVE";
export const inactiveStatus = "INACTIVE";
export const allStatus = "ALL";