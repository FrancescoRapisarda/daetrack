import { Component, OnInit } from '@angular/core';
import { DaeService } from '../../services/dae.service';
import { Map, latLng, tileLayer, LayerGroup, MapOptions, Marker, Circle, Icon, DomEvent } from "leaflet";
import { environment } from '../../../environments/environment'; 
import { DaeCardComponent } from '../dae-card/dae-card.component';
import { DAEparams } from '../../interfaces/DAEparams';
import { DAEdata } from '../../interfaces/DAEdata';
import { defaultDistance, defaultLatitude, defaultLongitude, activeStatus, allStatus, inactiveStatus } from '../../common/constants/constants';
import { SliderComponent } from "../slider/slider.component";
import { ToolbarComponent } from '../toolbar/toolbar.component';

@Component({
  selector: 'app-leaflet-map',
  standalone: true,
  imports: [DaeCardComponent, SliderComponent, ToolbarComponent],
  templateUrl: './leaflet-map.component.html',
  styleUrl: './leaflet-map.component.scss'
})
export class LeafletMapComponent implements OnInit{
  map!: Map;
  markersLayer!: LayerGroup;
  DAEList: DAEparams[] = [];
  clickCount: number = 0;
  selectedDae: DAEparams | undefined; 
  selectedMarker!: HTMLElement; 
  previousMarker: HTMLElement | undefined; 

  distance: number = defaultDistance;
  userLatitude: number = defaultLatitude;
  userLongitude: number = defaultLongitude;
  currentStatus: string = allStatus;
  circle!: Circle | null;

  isLogged: boolean = true;
  
  constructor(private daeService: DaeService){}

  options: MapOptions = {
    center: latLng(37.4922300, 15.0704100),
    zoom: 14
  };

  ngOnInit(): void {
    this.initMap();
  }

  private onMarkerClick(selectedDaeId: string, event: any): void {
    const DAEcard = document.querySelector('.dae-card') as HTMLElement;

    if(DAEcard){
      DAEcard.classList.remove('dae-card-hidden');
    }

    this.clickCount++;
    this.selectedDae = this.DAEList.find(d => d.ID === selectedDaeId);

    if(this.previousMarker && this.clickCount > 1){
      // levare stile previousDae
      this.previousMarker.style.width = "45px";
      this.previousMarker.style.height = "35px";
      this.previousMarker.style.border = "none";
      this.previousMarker.style.borderRadius = "0";
    }

    this.selectedMarker = event.target.getElement();
    this.previousMarker = this.selectedMarker;
    
    if(this.selectedMarker){
      this.selectedMarker.style.width = "60px";
      this.selectedMarker.style.height = "auto";
      this.selectedMarker.style.border = "4px solid #0A9BD8";
      this.selectedMarker.style.borderRadius = "12px";
    }
  }

  private changeZoomStyle(): void {
    //const zoomButton = document.querySelector('.leaflet-control-zoom .leaflet-bar .leaflet-control') as HTMLElement;
    const zoomInButton = document.querySelector('.leaflet-control-zoom-in') as HTMLElement;
    const zoomOutButton = document.querySelector('.leaflet-control-zoom-out') as HTMLElement;
    //zoomButton.style.top = "-100px";
    zoomInButton.style.color = '#0A9BD8';
    zoomOutButton.style.color = '#0A9BD8';
  }

  private updateMap(distance: number): void{
    // Remove previous markers
    if(this.map.hasLayer(this.markersLayer))
      this.markersLayer.clearLayers();

    this.getDAE();
    this.drawCircle(this.userLatitude, this.userLongitude, distance);
  }

  public onDistanceChange(event: any): void{
    this.distance = event.target.value;
    this.updateMap(this.distance);
  }

  private drawCircle(lat: number, lng: number, distance: number){
    // Remove the previous circle
    if(this.circle)
      this.map.removeLayer(this.circle);
      
    this.circle = new Circle([lat, lng], {radius: distance}).addTo(this.map);
    this.circle.setStyle({color: "#0A9BD8"});
  }

  private getDAE(): void{
    let daeData: DAEdata = {
      latitude: this.userLatitude,
      longitude: this.userLongitude,
      distance: this.distance,
      status: this.currentStatus
    }

    // API request
    this.daeService.getDAEByDistance(daeData).subscribe((response: any) => {
      this.DAEList = response.DAEList;

      this.DAEList.forEach(element => {
        let elementIconUrl: string = '';
        
        switch(element.Status){
          case 'ACTIVE':
            elementIconUrl = 'assets/icons/DAEpin-green.png';
            break;
  
          case 'YELLOW':
            elementIconUrl = 'assets/icons/DAEpin-yellow.png';
            break;
  
          case 'INACTIVE':
            elementIconUrl = 'assets/icons/DAEpin-red.png';
            break;
        }
  
        // Icon
        let leafIcon = new Icon({
          iconUrl: elementIconUrl,
          iconSize: [45, 35]
        });
  
        let marker = new Marker([Number(element.Latitude), Number(element.Longitude)], {icon: leafIcon}).addTo(this.map!);
        marker.addEventListener("click", (event) => this.onMarkerClick(element.ID, event));

        // Add the marker to markersLayer
        marker.addTo(this.markersLayer);
      });

      // Add markersLayer to the map
      this.map.addLayer(this.markersLayer);
    });
  }
  
  private initMap(): void {
    const key = environment.apiKey;

    this.map = new Map('map', this.options);
    this.map.locate({setView: true, maxZoom: 15});

    this.markersLayer = new LayerGroup();

    // To prevent the map being dragged when dragging/clicking the slider
    const slider = document.getElementById('slider');
    if (slider) {
      DomEvent.disableClickPropagation(slider); 
      DomEvent.disableScrollPropagation(slider); 
    }

    /* MODIFICARE STILE SLIDER
    const active = document.querySelector('.mdc-slider__track--active_fill') as HTMLElement;
    const inactive = document.querySelector('.mdc-slider__track--inactive') as HTMLElement;
    const slider_thumb = document.querySelector('.mdc-slider__thumb-knob') as HTMLElement;
    inactive.style.backgroundColor = "#0A9BD8";
    active.style.borderColor = "#0A9BD8";
    slider_thumb.style.backgroundColor = "#0A9BD8"; */
    
    // When the user location is found
    this.map.on('locationfound', (locationEvent) => {
      this.userLatitude = locationEvent.latlng.lat;
      this.userLongitude = locationEvent.latlng.lng;

      this.drawCircle(this.userLatitude, this.userLongitude, defaultDistance);
      //let userMarker = new Marker([this.userLatitude, this.userLongitude]).addTo(this.map!);
      this.getDAE();
    });
    
    const zoomControl = this.map.zoomControl;
    zoomControl.setPosition('bottomright');
    this.changeZoomStyle();

    tileLayer(`https://api.maptiler.com/maps/streets-v2/{z}/{x}/{y}.png?key=${key}`, {
      tileSize: 512,
      zoomOffset: -1,
      minZoom: 1,
      attribution: "\u003ca href=\"https://www.maptiler.com/copyright/\" target=\"_blank\"\u003e\u0026copy; MapTiler\u003c/a\u003e \u003ca href=\"https://www.openstreetmap.org/copyright\" target=\"_blank\"\u003e\u0026copy; OpenStreetMap contributors\u003c/a\u003e",
      crossOrigin: true
    }).addTo(this.map!);
  }
}
