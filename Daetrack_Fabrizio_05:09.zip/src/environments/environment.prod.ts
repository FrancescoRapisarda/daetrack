export const environment = {
    production: true,
    apiKey: 'OPEfAKkldeAZ6hRP0N0p'
  };
  