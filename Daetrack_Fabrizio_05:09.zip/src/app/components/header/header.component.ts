import { Component } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [TranslateModule,RouterModule,FormsModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  searchQuery: string = '';
  constructor(private translate: TranslateService){}

  changeLang(lang: string): void {
    this.translate.use(lang);
  }
  onSearch(): void {
    console.log(this.searchQuery); // aggiungere logica
  }
}
