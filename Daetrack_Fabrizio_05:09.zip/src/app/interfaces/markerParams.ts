export interface markerParams{
    id: number,
    latitude: number,
    langitude: number
}